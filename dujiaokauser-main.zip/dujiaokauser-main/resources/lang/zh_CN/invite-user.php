<?php 
return [
    'labels' => [
        'InviteUser' => '返利记录',
        'invite-user' => '返利记录',
    ],
    'fields' => [
        'user_id' => '用户ID',
        'user_pid' => '上级ID',
        'order_id' => '订单号ID',
        'amount' => '返利金额',
        'status' => '状态',
        'withdraw_id' => '提现ID',
    ],
    'options' => [
    ],
];
